from django.apps import AppConfig


class BlockchainConfig(AppConfig):
    name = 'blockchain'
