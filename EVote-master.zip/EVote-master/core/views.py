from django.shortcuts import render
import os

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings as django_settings
from PIL import Image
import datetime


def auth_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.add_message(request, messages.SUCCESS, 'Welcome back!')
            return redirect('home')
        else:
            messages.add_message(request, messages.ERROR, 'Invalid credentials')
            return render(request, 'core/login.html')
    return render(request, 'core/login.html')


def auth_logout(request):
    if not request.user.is_authenticated:
        return redirect('login')
    logout(request)
    messages.add_message(request, messages.INFO, 'Hope to see you soon!')
    return redirect('login')


def home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    return render(request, 'core/home.html')


def forgot_pass(request):
    if request.method == "POST":
        username = request.POST.get('username')

        user = User.objects.filter(username=username)
        print(user)
        if user:
            return redirect('forgot_pass_success', username)
        else:
            return redirect('forgot_pass_error')
    else:
        return render(request, 'core/forgot_pass.html')


def forgot_pass_success(request, username):
    return render(request, 'core/success.html', {
        'username': username
    })


def forgot_pass_error(request):
    messages.add_message(request, messages.ERROR, 'Invalid username :\'(')
    return render(request, 'core/forgot_pass.html')


def success_change_pass(request, username):
    user = User.objects.get(username=username)
    password = request.POST.get('password')

    print(user)

    user.set_password(password)
    user.save()
    messages.add_message(request, messages.SUCCESS, 'Your password has been reset. Try login with new password.')
    return redirect('login')