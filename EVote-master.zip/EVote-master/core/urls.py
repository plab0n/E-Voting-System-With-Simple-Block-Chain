from django.contrib import admin
from django.urls import path, include
from. import views

urlpatterns = [
    path('login/', views.auth_login, name='login'),
    path('logout/', views.auth_logout, name='logout'),
    path('forgot_pass/', views.forgot_pass, name='forgot_pass'),
    path('forgot_pass_success/<slug:username>', views.forgot_pass_success, name='forgot_pass_success'),
    path('forgot_pass_error', views.forgot_pass_error, name='forgot_pass_error'),
    path('success_change_pass/<slug:username>', views.success_change_pass, name='success_change_pass'),

    path('home/', views.home, name='home'),

]