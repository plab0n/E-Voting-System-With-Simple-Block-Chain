from django.contrib import admin
from django.urls import path, include
from. import views

urlpatterns = [
    path('nomination/<int:pk>/', views.nomination, name='nomination'),
    path('nomination_home/', views.nomination_home, name='nomination_home'),
    path('view_nominated_list/<int:pk>/', views.view_nominated_list, name='view_nominated_list'),

]