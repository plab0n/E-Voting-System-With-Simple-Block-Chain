from django.db import models

# Create your models here.

from django.contrib.auth.models import User
from django.db import models


# Create your models here.'
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.safestring import mark_safe
from superadmin.models import Scheme


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    scheme = models.ManyToManyField(Scheme)


class Nomination(models.Model):
    who = models.ForeignKey(User, on_delete=models.CASCADE, related_name='nominator')
    whom = models.ForeignKey(User, on_delete=models.CASCADE, related_name='nominee')
    # pos = models.CharField(max_length=255)
    pos = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='category')
    scheme = models.ManyToManyField(Scheme)
