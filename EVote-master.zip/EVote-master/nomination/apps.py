from django.apps import AppConfig


class NominationConfig(AppConfig):
    name = 'nomination'
