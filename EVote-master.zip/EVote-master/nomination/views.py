from django.shortcuts import render
from django.shortcuts import render
import os

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings as django_settings
from PIL import Image
import datetime
from django.conf import settings

from .models import Nomination, Category
from superadmin.models import Scheme

# Create your views here.


def nomination_home(request):
    return render(request, 'nomination/nomination_home.html')


def nomination(request, pk):
    sc = Scheme.objects.get(pk=request.session['scheme'])
    print(sc.START_TIME, datetime.datetime.now())

    if datetime.datetime.now() < sc.START_TIME.replace(tzinfo=None):
        if request.method == "POST":
            who = request.user
            whom = request.POST.get('candidate')
            _user = User.objects.filter(username=whom)[0]
            pos = Category.objects.get(pk=pk)

            print(whom, pos)

            n = Nomination.objects.create(who=who, whom=_user, pos=pos)
            n.scheme.add(sc)
            n.save()

            # obj = Nomination.objects.filter(pos=pos)

            obj = sc.nomination_set.all()

            print(len(obj))

            return redirect('view_nominated_list', sc.pk)

            # return render(request, 'nomination/nominated_list.html', {
            #     'candidate': obj,
            # })
        else:
            obj = Nomination.objects.filter(who=request.user)
            print(obj)
            user_obj = User.objects.all()
            for i in obj:
                user_obj = user_obj.exclude(username=i.whom.username)

            print(user_obj)
            pos = Category.objects.get(pk=pk)
            print(pos)
            return render(request, 'nomination/nomination.html', {
                'candidate': user_obj,
                'title': pos,
            })
    else:
        if sc.START_TIME.replace(tzinfo=None) < datetime.datetime.now():
            to = 0
        else:
            to = 1
        pos = Category.objects.get(pk=pk)
        return render(request, 'nomination/nomination.html', {
            'time_over': to,
            'title': pos,
        })


def view_nominated_list(request, pk):
    sc = Scheme.objects.get(pk=pk)
    obj = sc.nomination_set.all()
    return render(request, 'nomination/view_nomination_list.html', {
        'obj': obj,
    })