from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.urls import reverse
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_text
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.contrib.auth import update_session_auth_hash
from django.conf import settings
import sendgrid
from sendgrid.helpers.mail import *




def validate_user(request, username, _email):
    try:
        user = User.objects.get(Q(username=username) | Q(email=_email))
    except User.DoesNotExist:
        user = None

    if user is not None:
        # user already exists
        return True
    else:
        return False


# Create your views here.
def register(request):
    # user = request.user
    if request.method == 'POST':
        username = request.POST.get('username')
        print(username)
        _email = request.POST.get('email')
        password = request.POST.get('password')
        print(password)

        if validate_user(request, username, _email):
            # user already exists
            msg = "User with this username or email already exists! :("
            messages.add_message(request, messages.ERROR, msg)
            return render(request, 'auth/register.html', {
                'user_state': "exists",
            })
        else:
            # new user
            user = User.objects.create_user(username, _email, password)

            user.save()

            login(request, user)
            msg = "Welcome to the E Voting system"
            messages.add_message(request, messages.SUCCESS, msg)
            """
            @send user the first puzzle whose pk is 1
            """
            return redirect('home')

    else:
        return render(request, 'auth/register.html')
        # if user.is_authenticated:
        #     return render(request, 'core_front_end/why_yoy_lyin.html')
        # else:
        #     return render(request, 'core_front_end/register.html')