from django.db import models

# Create your models here.


class Scheme(models.Model):
    name = models.CharField(max_length=250, unique=True)
    START_TIME = models.DateTimeField(blank=True, null=True)
    CUT_OFF_TIME = models.DateTimeField(blank=True, null=True)
    END_TIME = models.DateTimeField(blank=True, null=True)