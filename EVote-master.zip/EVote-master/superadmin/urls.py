from django.contrib import admin
from django.urls import path, include
from. import views

urlpatterns = [
    path('scheme', views.scheme, name='scheme'),
    path('scheme_detail/<int:pk>', views.scheme_detail, name='scheme_detail'),

]