from django.contrib import admin

# Register your models here.
from .models import Scheme
from nomination.models import Category

admin.site.register(Scheme)
admin.site.register(Category)