from django.shortcuts import render
from .models import Scheme
import datetime

# Create your views here.


def scheme(request):
    obj = Scheme.objects.filter(END_TIME__gt=datetime.datetime.now())
    return render(request, 'core/current_schemes.html', {
        'obj': obj,
    })


def scheme_detail(request, pk):
    request.session['scheme'] = pk
    obj = Scheme.objects.get(pk=pk)
    print(obj.START_TIME)
    print(datetime.datetime.now())
    if obj.START_TIME.replace(tzinfo=None) > datetime.datetime.now():
        nomination = 1
    else:
        nomination = 0
    print(nomination)
    return render(request, 'core/scheme_detail.html', {
        'obj': obj,
        'nomination': nomination,
    })